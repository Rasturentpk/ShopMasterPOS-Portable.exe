# ShopMaster POS — Stage 1 (foundation)

## Build the installer (on a Windows PC with Node.js 20+)
```
npm install
npm run dev     # develop with hot reload
npm run dist    # creates release/ShopMasterPOS-Setup.exe and release/ShopMasterPOS-Portable.exe
```
Shop owners only run the .exe; they need nothing else installed.

## In this stage
Electron main/preload (context isolation, sandbox, no Node in renderer), SQLite schema (all 11 tables, foreign keys),
first-run shop + owner setup, bcrypt login, role permissions, dark/light glass theme,
database backup and restore, and the installer config (desktop + Start Menu shortcuts, runs after install).
Data lives in %APPDATA%/ShopMaster POS/shopmaster.db.

## Next stages
2 products, categories, inventory, POS  |  3 customers, sales history, expenses, receipts  |  4 dashboard, charts, reports, users, settings
