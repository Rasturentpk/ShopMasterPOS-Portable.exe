import React, { useEffect, useState } from 'react';

const NAV = [
  ['Dashboard', ['*', 'MANAGER']], ['POS / New Sale', ['*', 'MANAGER', 'CASHIER']],
  ['Products', ['*', 'MANAGER']], ['Categories', ['*', 'MANAGER']], ['Inventory', ['*', 'MANAGER']],
  ['Customers', ['*', 'MANAGER', 'CASHIER']], ['Sales History', ['*', 'MANAGER', 'CASHIER']],
  ['Expenses', ['*', 'MANAGER']], ['Reports', ['*', 'MANAGER']], ['Users', ['*']],
  ['Settings', ['*']], ['Backup & Restore', ['*']]
];
const allowed = (role, roles) => (role === 'OWNER' ? true : roles.includes(role));

function Field({ label, children }) {
  return <label className="field"><span>{label}</span>{children}</label>;
}

function Setup({ onDone }) {
  const [step, setStep] = useState(1);
  const [f, setF] = useState({ shopName: '', ownerName: '', phone: '', address: '', currency: 'Rs.', receiptPrinter: '', receiptSize: '80mm', username: '', password: '', confirm: '' });
  const [printers, setPrinters] = useState([]);
  const [err, setErr] = useState('');
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const next = (e) => {
    e.preventDefault(); setErr('');
    if (!f.shopName.trim() || !f.ownerName.trim()) return setErr('Enter the shop name and owner name.');
    setStep(2);
  };
  const finish = async (e) => {
    e.preventDefault(); setErr('');
    if (f.password !== f.confirm) return setErr('Passwords do not match.');
    const r = await window.api.completeSetup(f);
    if (!r.ok) return setErr(r.error);
    onDone();
  };
  return (
    <div className="center">
      <form className="glass panel" onSubmit={step === 1 ? next : finish}>
        <h1>{step === 1 ? 'Set up your shop' : 'Create the owner account'}</h1>
        <p className="muted">{step === 1 ? 'This information appears on receipts. You can change it later in Settings.' : 'The owner has full access. Choose a password you will remember.'}</p>
        {step === 1 ? (<>
          <Field label="Shop name"><input autoFocus value={f.shopName} onChange={set('shopName')} /></Field>
          <Field label="Owner name"><input value={f.ownerName} onChange={set('ownerName')} /></Field>
          <div className="row">
            <Field label="Phone"><input value={f.phone} onChange={set('phone')} /></Field>
            <Field label="Currency"><input value={f.currency} onChange={set('currency')} /></Field>
          </div>
          <Field label="Address"><input value={f.address} onChange={set('address')} /></Field>
          <div className="row">
            <Field label="Receipt printer">
              <select value={f.receiptPrinter} onChange={set('receiptPrinter')}>
                <option value="">Windows default printer</option>
                {printers.map((p) => <option key={p}>{p}</option>)}
              </select>
            </Field>
            <Field label="Receipt size">
              <select value={f.receiptSize} onChange={set('receiptSize')}><option>80mm</option><option>58mm</option></select>
            </Field>
          </div>
        </>) : (<>
          <Field label="Username"><input autoFocus value={f.username} onChange={set('username')} autoComplete="off" /></Field>
          <Field label="Password"><input type="password" value={f.password} onChange={set('password')} /></Field>
          <Field label="Confirm password"><input type="password" value={f.confirm} onChange={set('confirm')} /></Field>
        </>)}
        {err && <div className="error" role="alert">{err}</div>}
        <div className="row end">
          {step === 2 && <button type="button" className="btn ghost" onClick={() => setStep(1)}>Back</button>}
          <button className="btn primary">{step === 1 ? 'Continue' : 'Create shop'}</button>
        </div>
      </form>
    </div>
  );
}

function Login({ shopName, onLogin }) {
  const [u, setU] = useState(localStorage.getItem('sm_user') || '');
  const [p, setP] = useState('');
  const [show, setShow] = useState(false);
  const [remember, setRemember] = useState(!!localStorage.getItem('sm_user'));
  const [err, setErr] = useState('');
  const submit = async (e) => {
    e.preventDefault(); setErr('');
    const r = await window.api.login({ username: u, password: p });
    if (!r.ok) return setErr(r.error);
    if (remember) localStorage.setItem('sm_user', u); else localStorage.removeItem('sm_user');
    onLogin(r);
  };
  return (
    <div className="center">
      <form className="glass panel narrow enter" onSubmit={submit}>
        <div className="logo">{(shopName || 'S')[0]}</div>
        <h1>{shopName || 'ShopMaster POS'}</h1>
        <p className="muted">Sign in to start selling.</p>
        <Field label="Username"><input autoFocus value={u} onChange={(e) => setU(e.target.value)} autoComplete="username" /></Field>
        <Field label="Password">
          <div className="pw">
            <input type={show ? 'text' : 'password'} value={p} onChange={(e) => setP(e.target.value)} autoComplete="current-password" />
            <button type="button" className="btn ghost small" onClick={() => setShow(!show)}>{show ? 'Hide' : 'Show'}</button>
          </div>
        </Field>
        <label className="check"><input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} /> Remember my username</label>
        {err && <div className="error" role="alert">{err}</div>}
        <button className="btn primary big">Sign in</button>
      </form>
    </div>
  );
}

function Shell({ session, onLogout, onTheme }) {
  const { user, settings } = session;
  const [page, setPage] = useState('Dashboard');
  const [msg, setMsg] = useState('');
  const [now, setNow] = useState(new Date());
  useEffect(() => { const t = setInterval(() => setNow(new Date()), 30000); return () => clearInterval(t); }, []);

  const backup = async () => { const r = await window.api.createBackup(); setMsg(r.ok ? `Backup saved to ${r.path}` : r.error || ''); };
  const restore = async () => { const r = await window.api.restoreBackup(); if (!r.ok && r.error) setMsg(r.error); };

  return (
    <div className="shell">
      <aside className="glass sidebar">
        <div className="brand"><div className="logo sm">{settings.shop_name[0]}</div><b>{settings.shop_name}</b></div>
        <nav>
          {NAV.filter(([, roles]) => allowed(user.role, roles)).map(([n]) => (
            <button key={n} className={'nav' + (page === n ? ' active' : '')} onClick={() => setPage(n)}>{n}</button>
          ))}
        </nav>
        <button className="nav" onClick={onLogout}>Logout</button>
      </aside>
      <div className="main">
        <header className="glass topbar">
          <span>{now.toLocaleDateString(undefined, { weekday: 'long', day: 'numeric', month: 'long' })}, {now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
          <span className="grow" />
          <button className="btn ghost small" onClick={onTheme}>{settings.theme === 'light' ? 'Dark glass' : 'Light glass'}</button>
          <span className="who">{user.full_name} <small>{user.role}</small></span>
        </header>
        <section className="glass content">
          <h1>{page}</h1>
          {page === 'Backup & Restore' ? (<>
            <p className="muted">Back up your shop data to a file, or restore from one. Restoring replaces everything and restarts the app.</p>
            <div className="row"><button className="btn primary" onClick={backup}>Back up database</button><button className="btn ghost" onClick={restore}>Restore database</button></div>
            {msg && <p role="status">{msg}</p>}
          </>) : (
            <p className="muted">The {page.toLowerCase()} screen is built in the next stage. The database, sign-in and permissions behind it are ready.</p>
          )}
        </section>
      </div>
    </div>
  );
}

export default function App() {
  const [state, setState] = useState('loading');
  const [session, setSession] = useState(null);
  const [shopName, setShopName] = useState('');
  useEffect(() => { document.documentElement.dataset.theme = session?.settings?.theme || 'dark'; }, [session]);
  useEffect(() => { (async () => {
    const s = await window.api.setupStatus();
    setState(s.needsSetup ? 'setup' : 'login');
  })(); }, []);

  if (state === 'loading') return <div className="center"><div className="skeleton" /></div>;
  if (state === 'setup') return <><Blobs /><Setup onDone={() => setState('login')} /></>;
  if (!session) return <><Blobs /><Login shopName={shopName} onLogin={(r) => { setShopName(r.settings.shop_name); setSession(r); setState('app'); }} /></>;
  return <><Blobs /><Shell session={session}
    onLogout={async () => { await window.api.logout(); setSession(null); }}
    onTheme={async () => { const t = session.settings.theme === 'light' ? 'dark' : 'light'; await window.api.setTheme(t); setSession({ ...session, settings: { ...session.settings, theme: t } }); }} /></>;
}
function Blobs() { return <div className="blobs" aria-hidden="true"><i /><i /><i /></div>; }
