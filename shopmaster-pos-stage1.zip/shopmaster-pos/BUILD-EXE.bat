@echo off
title ShopMaster POS - Build installer
where node >nul 2>nul || (echo Node.js 20+ is required to build. Install it from https://nodejs.org then run this again. & pause & exit /b 1)
call npm install || (echo npm install failed & pause & exit /b 1)
call npm run dist || (echo Build failed & pause & exit /b 1)
echo.
echo Done. Opening the release folder...
start "" "%~dp0release"
pause
