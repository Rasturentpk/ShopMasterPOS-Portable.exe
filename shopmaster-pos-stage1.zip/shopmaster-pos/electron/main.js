const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const bcrypt = require('bcryptjs');
const dbm = require('./db');

const DEV = process.env.ELECTRON_DEV === '1';
let win;
let session = null; // lives only in the main process, never in the renderer

const PERMS = {
  OWNER: ['*'],
  MANAGER: ['products', 'inventory', 'sales', 'customers', 'reports', 'categories', 'pos', 'expenses'],
  CASHIER: ['pos', 'customers', 'sales']
};
const can = (area) => !!session && (PERMS[session.role].includes('*') || PERMS[session.role].includes(area));
const str = (v, max = 200) => (typeof v === 'string' ? v.trim().slice(0, max) : '');
const fail = (error) => ({ ok: false, error });

function settingsObj() {
  const rows = dbm.get().prepare('SELECT key, value FROM ShopSettings').all();
  return Object.fromEntries(rows.map((r) => [r.key, r.value]));
}

function createWindow() {
  win = new BrowserWindow({
    width: 1400, height: 880, minWidth: 1100, minHeight: 700,
    backgroundColor: '#0b1020', show: false, title: 'ShopMaster POS',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true, nodeIntegration: false, sandbox: true, webSecurity: true
    }
  });
  win.once('ready-to-show', () => win.show());
  win.setMenuBarVisibility(false);
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-navigate', (e) => e.preventDefault());
  if (DEV) win.loadURL('http://localhost:5173');
  else win.loadFile(path.join(__dirname, '../dist/index.html'));
}

function registerIpc() {
  ipcMain.handle('setup:status', () => ({
    needsSetup: dbm.get().prepare('SELECT COUNT(*) c FROM Users').get().c === 0
  }));

  ipcMain.handle('setup:complete', (_e, p) => {
    if (dbm.get().prepare('SELECT COUNT(*) c FROM Users').get().c > 0) return fail('Setup is already complete.');
    const shop = {
      shop_name: str(p?.shopName, 80), owner_name: str(p?.ownerName, 80), phone: str(p?.phone, 30),
      address: str(p?.address, 200), currency: str(p?.currency, 10) || 'Rs.',
      receipt_printer: str(p?.receiptPrinter, 120), receipt_size: p?.receiptSize === '58mm' ? '58mm' : '80mm',
      theme: 'dark', tax_percent: '0', next_invoice: '1'
    };
    const username = str(p?.username, 40);
    const password = typeof p?.password === 'string' ? p.password : '';
    if (!shop.shop_name || !shop.owner_name) return fail('Shop name and owner name are required.');
    if (!/^[a-zA-Z0-9_.-]{3,40}$/.test(username)) return fail('Username needs 3-40 letters, numbers, dots, dashes or underscores.');
    if (password.length < 6) return fail('Password needs at least 6 characters.');
    const hash = bcrypt.hashSync(password, 10);
    const d = dbm.get();
    d.transaction(() => {
      const ins = d.prepare('INSERT INTO ShopSettings (key, value) VALUES (?, ?)');
      Object.entries(shop).forEach(([k, v]) => ins.run(k, v));
      d.prepare('INSERT INTO Users (username, password_hash, full_name, role) VALUES (?,?,?,?)')
        .run(username, hash, shop.owner_name, 'OWNER');
    })();
    return { ok: true };
  });

  ipcMain.handle('auth:login', (_e, p) => {
    const username = str(p?.username, 40);
    const password = typeof p?.password === 'string' ? p.password : '';
    const u = dbm.get().prepare('SELECT * FROM Users WHERE username = ? AND active = 1').get(username);
    if (!u || !bcrypt.compareSync(password, u.password_hash)) return fail('Incorrect username or password.');
    session = { id: u.id, username: u.username, full_name: u.full_name, role: u.role };
    return { ok: true, user: session, settings: settingsObj() };
  });
  ipcMain.handle('auth:logout', () => { session = null; return { ok: true }; });
  ipcMain.handle('auth:me', () => (session ? { ok: true, user: session, settings: settingsObj() } : fail('Not signed in.')));

  ipcMain.handle('settings:setTheme', (_e, theme) => {
    if (!session) return fail('Not signed in.');
    dbm.get().prepare("INSERT INTO ShopSettings (key,value) VALUES ('theme',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value")
      .run(theme === 'light' ? 'light' : 'dark');
    return { ok: true };
  });

  ipcMain.handle('printers:list', async () => {
    if (!can('pos')) return fail('Not allowed.');
    return { ok: true, printers: (await win.webContents.getPrintersAsync()).map((p) => p.name) };
  });

  ipcMain.handle('backup:create', async () => {
    if (!can('*')) return fail('Only the owner can back up.');
    const stamp = new Date().toISOString().slice(0, 10);
    const r = await dialog.showSaveDialog(win, {
      defaultPath: `ShopMasterPOS_Backup_${stamp}.db`, filters: [{ name: 'Database', extensions: ['db'] }]
    });
    if (r.canceled || !r.filePath) return { ok: false, canceled: true };
    await dbm.get().backup(r.filePath);
    return { ok: true, path: r.filePath };
  });

  ipcMain.handle('backup:restore', async () => {
    if (!can('*')) return fail('Only the owner can restore.');
    const pick = await dialog.showOpenDialog(win, { filters: [{ name: 'Database', extensions: ['db'] }], properties: ['openFile'] });
    if (pick.canceled || !pick.filePaths[0]) return { ok: false, canceled: true };
    const confirm = await dialog.showMessageBox(win, {
      type: 'warning', buttons: ['Cancel', 'Restore'], defaultId: 0, cancelId: 0,
      message: 'Replace all current shop data with this backup?',
      detail: 'Current data is saved as a safety copy first. The app will restart.'
    });
    if (confirm.response !== 1) return { ok: false, canceled: true };
    const src = pick.filePaths[0];
    const Database = require('better-sqlite3');
    try { const t = new Database(src, { readonly: true }); t.prepare('SELECT COUNT(*) FROM Users').get(); t.close(); }
    catch { return fail('That file is not a valid ShopMaster backup.'); }
    const live = dbm.dbPath();
    await dbm.get().backup(live + '.before-restore');
    dbm.close();
    ['-wal', '-shm'].forEach((s) => fs.rmSync(live + s, { force: true }));
    fs.copyFileSync(src, live);
    app.relaunch(); app.exit(0);
    return { ok: true };
  });
}

if (!app.requestSingleInstanceLock()) app.quit();
else {
  app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
  app.whenReady().then(() => { dbm.open(); registerIpc(); createWindow(); });
  app.on('window-all-closed', () => { dbm.close(); app.quit(); });
}
