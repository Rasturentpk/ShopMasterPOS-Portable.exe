const { contextBridge, ipcRenderer } = require('electron');
// Only fixed, named channels are exposed. No Node APIs reach the renderer.
const call = (ch) => (arg) => ipcRenderer.invoke(ch, arg);
contextBridge.exposeInMainWorld('api', {
  setupStatus: call('setup:status'), completeSetup: call('setup:complete'),
  login: call('auth:login'), logout: call('auth:logout'), me: call('auth:me'),
  setTheme: call('settings:setTheme'), listPrinters: call('printers:list'),
  createBackup: call('backup:create'), restoreBackup: call('backup:restore')
});
