const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');
const { app } = require('electron');

let db;
const dbPath = () => path.join(app.getPath('userData'), 'shopmaster.db');

const SCHEMA = `
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS Users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL,
  full_name TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('OWNER','MANAGER','CASHIER')),
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS ShopSettings (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS Categories (
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS Suppliers (
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT, address TEXT
);
CREATE TABLE IF NOT EXISTS Products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL, sku TEXT UNIQUE, barcode TEXT UNIQUE,
  category_id INTEGER REFERENCES Categories(id) ON DELETE SET NULL,
  supplier_id INTEGER REFERENCES Suppliers(id) ON DELETE SET NULL,
  purchase_price REAL NOT NULL DEFAULT 0 CHECK (purchase_price >= 0),
  sale_price REAL NOT NULL DEFAULT 0 CHECK (sale_price >= 0),
  stock REAL NOT NULL DEFAULT 0,
  min_stock REAL NOT NULL DEFAULT 0,
  image TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS Customers (
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT, address TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS Sales (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  invoice_no TEXT NOT NULL UNIQUE,
  customer_id INTEGER REFERENCES Customers(id) ON DELETE SET NULL,
  user_id INTEGER NOT NULL REFERENCES Users(id),
  subtotal REAL NOT NULL, discount REAL NOT NULL DEFAULT 0, tax REAL NOT NULL DEFAULT 0,
  total REAL NOT NULL, profit REAL NOT NULL DEFAULT 0,
  payment_method TEXT NOT NULL DEFAULT 'Cash',
  status TEXT NOT NULL DEFAULT 'COMPLETED' CHECK (status IN ('COMPLETED','VOID')),
  created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS SaleItems (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  sale_id INTEGER NOT NULL REFERENCES Sales(id) ON DELETE CASCADE,
  product_id INTEGER REFERENCES Products(id) ON DELETE SET NULL,
  product_name TEXT NOT NULL,
  quantity REAL NOT NULL CHECK (quantity > 0),
  unit_price REAL NOT NULL, purchase_price REAL NOT NULL DEFAULT 0,
  discount REAL NOT NULL DEFAULT 0, line_total REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS Payments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  sale_id INTEGER NOT NULL REFERENCES Sales(id) ON DELETE CASCADE,
  method TEXT NOT NULL, amount REAL NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS Expenses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  category TEXT NOT NULL CHECK (category IN ('Rent','Electricity','Salary','Transport','Maintenance','Other')),
  amount REAL NOT NULL CHECK (amount >= 0),
  expense_date TEXT NOT NULL, description TEXT,
  user_id INTEGER REFERENCES Users(id)
);
CREATE TABLE IF NOT EXISTS StockMovements (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  product_id INTEGER NOT NULL REFERENCES Products(id) ON DELETE CASCADE,
  change REAL NOT NULL,
  reason TEXT NOT NULL,
  ref_sale_id INTEGER REFERENCES Sales(id) ON DELETE SET NULL,
  user_id INTEGER REFERENCES Users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS idx_sales_date ON Sales(created_at);
CREATE INDEX IF NOT EXISTS idx_items_sale ON SaleItems(sale_id);
CREATE INDEX IF NOT EXISTS idx_products_barcode ON Products(barcode);
`;

function open() {
  fs.mkdirSync(app.getPath('userData'), { recursive: true });
  db = new Database(dbPath());
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');
  db.exec(SCHEMA);
  return db;
}
const get = () => db;
const close = () => { if (db) { db.close(); db = null; } };
module.exports = { open, get, close, dbPath };
